<template>
  <div class="rt-root">
    <!-- Header -->
    <header class="rt-hd">
      <div class="rt-hd-left">
        <span class="rt-live-dot"></span>
        <h1 class="rt-hd-title">实时健康监控</h1>
      </div>
      <div class="rt-hd-kpis">
        <div
          class="rt-kpi"
          v-for="k in headerKpis"
          :key="k.label"
          :style="k.clickable ? { cursor: 'pointer' } : {}"
          @click="k.onClick && k.onClick()">
          <span class="rt-kpi-n" :class="k.cls">{{ k.val }}</span>
          <span class="rt-kpi-l">{{ k.label }}</span>
        </div>
      </div>
      <div class="rt-hd-time">{{ currentTime }}</div>
    </header>

    <!-- Body -->
    <section class="rt-bd">
      <!-- Left: 6 vital metric cards -->
      <aside class="rt-aside">
        <div class="rt-vital" v-for="v in vitalCards" :key="v.key">
          <div class="rt-vital-ico" :style="{ background: v.bg }">
            <el-icon :size="22" :style="{ color: v.color }"><component :is="v.icon" /></el-icon>
          </div>
          <div class="rt-vital-info">
            <div class="rt-vital-val" :style="{ color: v.color }">{{ v.value }}</div>
            <div class="rt-vital-lbl">{{ v.label }}</div>
            <div class="rt-vital-sub">{{ v.sub }}</div>
          </div>
          <div class="rt-vital-dot" :class="v.dotCls"></div>
        </div>
      </aside>

      <!-- Center: table panel -->
      <main class="rt-main">
        <div class="rt-panel rt-table-panel">
          <!-- panel header with search bar -->
          <div class="rt-ph">
            <div class="rt-ph-left">
              <span class="rt-ph-dot"></span>
              <span class="rt-ph-title">在线用户实时状态</span>
              <span class="rt-badge-online">{{ filteredUserList.length }} 人在线</span>
              <!-- active filter hints -->
              <span v-if="hrFilter" class="rt-badge-filter" @click="hrFilter = null; currentPage = 1">
                心率: {{ hrFilter.label }} &times;
              </span>
            </div>
            <div class="rt-ph-right">
              <el-input
                v-model="searchForm.name"
                placeholder="姓名/工号"
                clearable
                class="rt-inp"
                @clear="handleSearch"
                @keyup.enter="handleSearch" />
              <el-select
                v-model="searchForm.dept"
                placeholder="全部部门"
                clearable
                class="rt-sel"
                @change="handleSearch">
                <el-option v-for="d in deptList" :key="d" :label="d" :value="d" />
              </el-select>
              <el-select
                v-model="searchForm.status"
                placeholder="全部状态"
                clearable
                class="rt-sel-sm"
                @change="handleSearch">
                <el-option label="仅正常" value="normal" />
                <el-option label="仅预警" value="warning" />
              </el-select>
              <button class="rt-btn" @click="handleSearch">
                <el-icon><Search /></el-icon> 查询
              </button>
              <button class="rt-btn rt-btn-g" @click="handleReset" title="重置">
                <el-icon><RefreshLeft /></el-icon>
              </button>
              <button
                class="rt-btn rt-btn-g"
                @click="toggleAutoScroll"
                :title="autoScrollEnabled ? '暂停滚动' : '开启滚动'">
                <el-icon><component :is="autoScrollEnabled ? 'VideoPause' : 'VideoPlay'" /></el-icon>
              </button>
            </div>
          </div>

          <!-- table -->
          <div
            class="rt-tbl-wrap"
            ref="tableWrapper"
            @mouseenter="pauseAutoScroll"
            @mouseleave="resumeAutoScroll">
            <el-table
              :data="paginatedUserList"
              style="width: 100%"
              :header-cell-style="tblHeadStyle"
              :cell-style="tblCellStyle"
              @row-click="showUserDetail">
              <el-table-column prop="userName" label="姓名" width="90" align="center">
                <template #default="{ row }">
                  <span class="c-name">{{ row.userName || '--' }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="userCode" label="工号" width="100" align="center">
                <template #default="{ row }">
                  <span class="c-code">{{ row.userCode || '--' }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="deptName" label="部门" width="130" align="center">
                <template #default="{ row }">
                  <span class="c-dept">{{ row.deptName || '--' }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="heartRate" label="心率(bpm)" width="110" align="center">
                <template #default="{ row }">
                  <span :class="hrCls(row.heartRate)">{{ row.heartRate || '--' }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="bloodOxygen" label="血氧(%)" width="100" align="center">
                <template #default="{ row }">
                  <span :class="spo2Cls(row.bloodOxygen)">
                    {{ row.bloodOxygen ? row.bloodOxygen + '%' : '--' }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="temperature" label="体温(°C)" width="100" align="center">
                <template #default="{ row }">
                  <span :class="tempCls(row.temperature)">
                    {{ row.temperature ? row.temperature + '°' : '--' }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="steps" label="步数" width="90" align="center">
                <template #default="{ row }">
                  <span class="c-steps">{{ row.steps != null ? row.steps : '--' }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="status" label="状态" width="90" align="center">
                <template #default="{ row }">
                  <span :class="['rt-status', row.status === 'normal' ? 'st-ok' : 'st-warn']">
                    {{ row.status === 'normal' ? '正常' : '预警' }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="lastUpdate" label="更新时间" align="center">
                <template #default="{ row }">
                  <span class="c-time">{{ fmtTime(row.lastUpdate) }}</span>
                </template>
              </el-table-column>
            </el-table>
          </div>

          <!-- pagination -->
          <div class="rt-pg">
            <button class="rt-pg-btn" :disabled="currentPage === 1" @click="currentPage = 1">首页</button>
            <button class="rt-pg-btn" :disabled="currentPage === 1" @click="currentPage--">&#8249;</button>
            <span class="rt-pg-info">{{ currentPage }} / {{ totalPages }}</span>
            <button class="rt-pg-btn" :disabled="currentPage >= totalPages" @click="currentPage++">&#8250;</button>
            <button class="rt-pg-btn" :disabled="currentPage >= totalPages" @click="currentPage = totalPages">末页</button>
            <span class="rt-pg-total">共 {{ filteredUserList.length }} 条</span>
          </div>
        </div>
      </main>

      <!-- Right: 3 ECharts panels -->
      <div class="rt-charts">
        <div class="rt-panel rt-cp">
          <div class="rt-cp-title">健康状态分布</div>
          <div ref="statusChartRef" class="rt-ec"></div>
        </div>
        <div class="rt-panel rt-cp rt-cp-md">
          <div class="rt-cp-title">部门在线分布</div>
          <div ref="deptChartRef" class="rt-ec"></div>
        </div>
        <div class="rt-panel rt-cp">
          <div class="rt-cp-title">心率区间分布</div>
          <div ref="hrChartRef" class="rt-ec"></div>
        </div>
      </div>
    </section>

    <!-- Detail dialog -->
    <el-dialog
      v-model="detailVisible"
      :title="(detailUser && detailUser.userName ? detailUser.userName : '') + ' 实时体征'"
      width="420px"
      :append-to-body="true"
      :close-on-click-modal="true">
      <div v-if="detailUser" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:8px 0">
        <div
          v-for="item in detailItems"
          :key="item.label"
          style="background:rgba(0,212,255,0.06);border:1px solid rgba(0,212,255,0.15);border-radius:8px;padding:12px 16px">
          <div style="font-size:11px;color:#8ba6c8;margin-bottom:4px">{{ item.label }}</div>
          <div :style="{ fontSize: '22px', fontWeight: '700', fontFamily: 'Consolas', color: item.color }">{{ item.value }}</div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import {
  getRealtimeOverview,
  getOnlineUsers,
  getRealtimeStatistics
} from '@/api/realtime'

export default {
  name: 'RealtimeMonitor',
  data() {
    return {
      currentTime: '',
      overview: {
        avgHeartRate: 0,
        avgBloodOxygen: 0,
        avgSteps: 0,
        avgTemperature: 0,
        avgSleep: 0,
        todayWarningCount: 0
      },
      statistics: {
        onlineUsers: 0,
        totalUsers: 0,
        weekRecords: 0,
        todayRecords: 0,
        onlineRate: 0,
        normalRate: 0
      },
      onlineUsers: { list: [], total: 0 },
      searchForm: { name: '', dept: '', status: '' },
      hrFilter: null,
      deptList: [],
      currentPage: 1,
      pageSize: 20,
      autoScrollEnabled: true,
      scrollPaused: false,
      refreshTimer: null,
      autoScrollTimer: null,
      resizeTimer: null,
      clockTimer: null,
      statusChart: null,
      deptChart: null,
      hrChart: null,
      detailUser: null,
      detailVisible: false,
      tblHeadStyle: {
        background: 'rgba(0,40,90,0.9)',
        color: '#00d4ff',
        borderColor: 'rgba(0,212,255,0.3)',
        fontSize: '13px',
        fontWeight: 'bold',
        padding: '10px 0'
      },
      tblCellStyle: {
        background: 'transparent',
        borderColor: 'rgba(0,212,255,0.15)',
        color: '#a8c5e6',
        fontSize: '13px',
        padding: '8px 0',
        cursor: 'pointer'
      }
    }
  },
  computed: {
    headerKpis() {
      const s = this.statistics
      const o = this.overview
      return [
        { label: '在线设备',   val: s.onlineUsers,         cls: 'kpi-green',  clickable: false, onClick: null },
        { label: '设备总数',   val: s.totalUsers,           cls: '',           clickable: false, onClick: null },
        {
          label: '在线率',
          val: s.onlineRate + '%',
          cls: this.rateCls(s.onlineRate),
          clickable: true,
          onClick: () => {
            ElMessage.info({
              message: `在线率 = 在线设备 / 设备总数 × 100%（当前：${s.onlineUsers} / ${s.totalUsers}）`,
              duration: 3000
            })
          }
        },
        { label: '健康正常率', val: s.normalRate + '%',     cls: this.rateCls(s.normalRate), clickable: false, onClick: null },
        {
          label: '近7天预警',
          val: o.todayWarningCount,
          cls: o.todayWarningCount > 0 ? 'kpi-warn' : 'kpi-green',
          clickable: true,
          onClick: () => {
            this.searchForm.status = this.searchForm.status === 'warning' ? '' : 'warning'
            this.currentPage = 1
          }
        },
        { label: '近7天记录',  val: s.todayRecords,         cls: '',           clickable: false, onClick: null }
      ]
    },
    vitalCards() {
      const o = this.overview
      return [
        {
          key: 'hr', label: '平均心率',
          value: o.avgHeartRate || '--', sub: '次/分钟',
          icon: 'Odometer', color: '#ef4444', bg: 'rgba(239,68,68,0.15)',
          dotCls: this.metricDot('hr', o.avgHeartRate)
        },
        {
          key: 'spo2', label: '平均血氧',
          value: o.avgBloodOxygen ? o.avgBloodOxygen + '%' : '--', sub: '正常 ≥95%',
          icon: 'DataLine', color: '#3b82f6', bg: 'rgba(59,130,246,0.15)',
          dotCls: this.metricDot('spo2', o.avgBloodOxygen)
        },
        {
          key: 'temp', label: '平均体温',
          value: o.avgTemperature ? o.avgTemperature + '°C' : '--', sub: '正常 36~37.5',
          icon: 'TrendCharts', color: '#f97316', bg: 'rgba(249,115,22,0.15)',
          dotCls: this.metricDot('temp', o.avgTemperature)
        },
        {
          key: 'steps', label: '平均步数',
          value: o.avgSteps || '--', sub: '步/天',
          icon: 'Histogram', color: '#22c55e', bg: 'rgba(34,197,94,0.15)',
          dotCls: 'dot-ok'
        },
        {
          key: 'warn', label: '近7天预警',
          value: o.todayWarningCount || 0, sub: '近7天累计',
          icon: 'Warning', color: '#E6A23C', bg: 'rgba(230,162,60,0.15)',
          dotCls: o.todayWarningCount > 0 ? 'dot-warn' : 'dot-ok'
        }
      ]
    },
    filteredUserList() {
      let list = this.onlineUsers.list || []
      if (this.searchForm.name) {
        const q = this.searchForm.name.trim().toLowerCase()
        list = list.filter(u =>
          (u.userName || '').toLowerCase().includes(q) ||
          (u.userCode || '').toLowerCase().includes(q)
        )
      }
      if (this.searchForm.dept) {
        list = list.filter(u => u.deptName === this.searchForm.dept)
      }
      if (this.searchForm.status) {
        list = list.filter(u => u.status === this.searchForm.status)
      }
      if (this.hrFilter) {
        list = list.filter(u => u.heartRate >= this.hrFilter.min && u.heartRate <= this.hrFilter.max)
      }
      return list
    },
    paginatedUserList() {
      const s = (this.currentPage - 1) * this.pageSize
      return this.filteredUserList.slice(s, s + this.pageSize)
    },
    totalPages() {
      return Math.max(1, Math.ceil(this.filteredUserList.length / this.pageSize))
    },
    detailItems() {
      const u = this.detailUser
      if (!u) return []
      return [
        {
          label: '心率',
          value: u.heartRate ? u.heartRate + ' bpm' : '--',
          color: this.hrCls(u.heartRate).includes('danger') ? '#ff5252'
            : this.hrCls(u.heartRate).includes('warn') ? '#ffd200' : '#52c41a'
        },
        {
          label: '血氧',
          value: u.bloodOxygen ? u.bloodOxygen + '%' : '--',
          color: this.spo2Cls(u.bloodOxygen).includes('danger') ? '#ff5252'
            : this.spo2Cls(u.bloodOxygen).includes('warn') ? '#ffd200' : '#52c41a'
        },
        {
          label: '体温',
          value: u.temperature ? u.temperature + '°C' : '--',
          color: this.tempCls(u.temperature).includes('danger') ? '#ff5252'
            : this.tempCls(u.temperature).includes('warn') ? '#ffd200' : '#52c41a'
        },
        { label: '步数',   value: u.steps != null ? u.steps + ' 步' : '--', color: '#22c55e' },
        { label: '部门',   value: u.deptName || '--',                         color: '#a8c5e6' },
        { label: '工号',   value: u.userCode || '--',                         color: '#a8c5e6' }
      ]
    }
  },
  watch: {
    filteredUserList() {
      this.$nextTick(() => this.updateCharts())
    }
  },
  mounted() {
    this.initTime()
    this.fetchData()
    this.autoRefresh()
    this.startAutoScroll()
    this.setScale()
    window.addEventListener('resize', this.handleResize)
    this.$nextTick(() => {
      this.initCharts()
    })
  },
  beforeUnmount() {
    clearInterval(this.refreshTimer)
    clearInterval(this.autoScrollTimer)
    clearInterval(this.clockTimer)
    clearTimeout(this.resizeTimer)
    window.removeEventListener('resize', this.handleResize)
    ;[this.statusChart, this.deptChart, this.hrChart].forEach(c => c && c.dispose())
  },
  methods: {
    initTime() {
      this.currentTime = dayjs().format('YYYY-MM-DD HH:mm:ss')
      this.clockTimer = setInterval(() => {
        this.currentTime = dayjs().format('YYYY-MM-DD HH:mm:ss')
      }, 1000)
    },

    async fetchData() {
      if (this._fetching) return
      this._fetching = true
      try {
        await Promise.all([
          this.fetchOverview(),
          this.fetchOnlineUsers(),
          this.fetchStatistics()
        ])
      } catch (e) {
        // 错误由各子方法自行处理，无需向上传播
      } finally {
        this._fetching = false
      }
    },

    async fetchOverview() {
      const r = await getRealtimeOverview()
      if (r.code === 200) this.overview = r.data
    },

    async fetchOnlineUsers() {
      const r = await getOnlineUsers(1, 10000)
      if (r.code === 200) {
        this.onlineUsers = r.data
        const depts = new Set((r.data.list || []).map(u => u.deptName).filter(Boolean))
        this.deptList = [...depts].sort()
      }
    },

    async fetchStatistics() {
      const r = await getRealtimeStatistics()
      if (r.code === 200) this.statistics = r.data
    },

    autoRefresh() {
      this.refreshTimer = setInterval(() => {
        this.fetchData()
      }, 5000)
    },

    handleSearch() {
      this.currentPage = 1
    },

    handleReset() {
      this.searchForm = { name: '', dept: '', status: '' }
      this.hrFilter = null
      this.currentPage = 1
    },

    startAutoScroll() {
      this.autoScrollTimer = setInterval(() => {
        if (!this.autoScrollEnabled || this.scrollPaused) return
        const el = this.$refs.tableWrapper
        if (!el) return
        const max = el.scrollHeight - el.clientHeight
        if (max <= 0) return
        el.scrollTop += 1
        if (el.scrollTop >= max) {
          setTimeout(() => { el.scrollTop = 0 }, 2000)
        }
      }, 50)
    },

    toggleAutoScroll() {
      this.autoScrollEnabled = !this.autoScrollEnabled
    },
    pauseAutoScroll() { this.scrollPaused = true },
    resumeAutoScroll() { this.scrollPaused = false },

    setScale() {
      const el = this.$el
      if (!el) return
      const menuWidth = 155
      const container = el.parentElement || el
      const vw = (container.clientWidth || window.innerWidth) - menuWidth
      const vh = window.innerHeight - 50
      const scale = Math.max(0.4, Math.min(2, Math.min(vw / 1920, vh / 1030)))
      el.style.transformOrigin = 'top left'
      el.style.transform = `scale(${scale})`
      el.style.width  = `${(1 / scale) * 100}%`
      el.style.height = `${(1 / scale) * vh}px`
    },

    handleResize() {
      clearTimeout(this.resizeTimer)
      this.resizeTimer = setTimeout(() => {
        this.setScale()
        if (!this.statusChart) {
          this.initCharts()
        } else {
          ;[this.statusChart, this.deptChart, this.hrChart].forEach(c => c && c.resize())
        }
      }, 200)
    },

    rateCls(v) {
      if (v >= 80) return 'kpi-green'
      if (v >= 60) return 'kpi-yellow'
      return 'kpi-warn'
    },

    metricDot(key, val) {
      if (!val) return 'dot-none'
      const map = {
        hr:    v => (v >= 60 && v <= 100) ? 'dot-ok' : (v >= 50 && v <= 120) ? 'dot-warn' : 'dot-danger',
        spo2:  v => v >= 97 ? 'dot-ok' : v >= 94 ? 'dot-warn' : 'dot-danger',
        temp:  v => (v >= 36.0 && v <= 37.3) ? 'dot-ok' : (v >= 35.5 && v <= 37.8) ? 'dot-warn' : 'dot-danger',
        sleep: v => (v >= 7 && v <= 9) ? 'dot-ok' : v >= 6 ? 'dot-warn' : 'dot-danger'
      }
      return map[key] ? map[key](val) : 'dot-ok'
    },

    hrCls(v) {
      if (!v) return 'c-dim'
      if (v < 50 || v > 120) return 'c-danger'
      if (v < 60 || v > 100) return 'c-warn'
      return 'c-ok'
    },

    spo2Cls(v) {
      if (!v) return 'c-dim'
      if (v < 90) return 'c-danger'
      if (v < 95) return 'c-warn'
      return 'c-ok'
    },

    tempCls(v) {
      if (!v) return 'c-dim'
      if (v < 35 || v > 38) return 'c-danger'
      if (v < 36 || v > 37.5) return 'c-warn'
      return 'c-ok'
    },

    fmtTime(t) {
      if (!t) return '--'
      return dayjs(t).format('HH:mm:ss')
    },

    showUserDetail(row) {
      this.detailUser = row
      this.detailVisible = true
    },

    initCharts() {
      this.statusChart = echarts.init(this.$refs.statusChartRef)
      this.deptChart   = echarts.init(this.$refs.deptChartRef)
      this.hrChart     = echarts.init(this.$refs.hrChartRef)
      this.updateCharts()
    },

    updateCharts() {
      this.renderStatusChart()
      this.renderDeptChart()
      this.renderHrChart()
    },

    renderStatusChart() {
      if (!this.statusChart) return
      const list   = this.filteredUserList
      const normal = list.filter(u => u.status === 'normal').length
      const warn   = list.filter(u => u.status !== 'normal').length
      this.statusChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} 人 ({d}%)',
          backgroundColor: 'rgba(0,20,50,0.92)',
          borderColor: 'rgba(0,212,255,0.3)',
          textStyle: { color: '#a8c5e6' }
        },
        legend: {
          bottom: 4,
          itemWidth: 10,
          itemHeight: 10,
          textStyle: { color: '#a8c5e6', fontSize: 12 }
        },
        series: [{
          type: 'pie',
          radius: ['52%', '74%'],
          center: ['50%', '44%'],
          data: [
            { value: normal, name: '健康正常', itemStyle: { color: '#67C23A' } },
            { value: warn,   name: '存在预警', itemStyle: { color: '#E6A23C' } }
          ],
          label: { show: false },
          emphasis: {
            label: { show: true, color: '#fff', fontSize: 13, fontWeight: 'bold' }
          }
        }]
      })
      this.statusChart.off('click')
      this.statusChart.on('click', (params) => {
        const statusVal = params.name === '健康正常' ? 'normal' : 'warning'
        if (this.searchForm.status === statusVal) {
          this.searchForm.status = ''
        } else {
          this.searchForm.status = statusVal
        }
        this.currentPage = 1
      })
    },

    renderDeptChart() {
      if (!this.deptChart) return
      const map = {}
      this.filteredUserList.forEach(u => {
        const d = u.deptName || '未知'
        map[d] = (map[d] || 0) + 1
      })
      const sorted = Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 8)
      const names  = sorted.map(e => e[0]).reverse()
      const values = sorted.map(e => e[1]).reverse()
      this.deptChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: 'rgba(0,20,50,0.92)',
          borderColor: 'rgba(0,212,255,0.3)',
          textStyle: { color: '#a8c5e6' }
        },
        grid: { top: 8, right: 30, bottom: 4, left: 4, containLabel: true },
        xAxis: {
          type: 'value',
          axisLabel: { color: '#8ba6c8', fontSize: 11 },
          splitLine: { lineStyle: { color: 'rgba(0,212,255,0.1)' } },
          axisLine: { show: false }
        },
        yAxis: {
          type: 'category',
          data: names,
          axisLabel: { color: '#a8c5e6', fontSize: 11 },
          axisLine: { lineStyle: { color: 'rgba(0,212,255,0.2)' } }
        },
        series: [{
          type: 'bar',
          data: values,
          barMaxWidth: 16,
          itemStyle: {
            color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
              { offset: 0, color: '#00d4ff' },
              { offset: 1, color: '#0044cc' }
            ]),
            borderRadius: [0, 4, 4, 0]
          },
          label: { show: true, position: 'right', color: '#a8c5e6', fontSize: 11 }
        }]
      })
      this.deptChart.off('click')
      this.deptChart.on('click', (params) => {
        if (this.searchForm.dept === params.name) {
          this.searchForm.dept = ''
        } else {
          this.searchForm.dept = params.name
        }
        this.currentPage = 1
      })
    },

    renderHrChart() {
      if (!this.hrChart) return
      const labels = ['过缓<50', '偏缓50~60', '正常61~100', '偏速101~120', '过速>120']
      const colors = ['#4FC3F7', '#81D4FA', '#67C23A', '#E6A23C', '#F56C6C']
      const counts = [0, 0, 0, 0, 0]
      this.filteredUserList.forEach(u => {
        const hr = u.heartRate
        if (!hr) return
        if      (hr < 50)  counts[0]++
        else if (hr <= 60) counts[1]++
        else if (hr <= 100)counts[2]++
        else if (hr <= 120)counts[3]++
        else               counts[4]++
      })
      this.hrChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: 'rgba(0,20,50,0.92)',
          borderColor: 'rgba(0,212,255,0.3)',
          textStyle: { color: '#a8c5e6' }
        },
        grid: { top: 10, right: 10, bottom: 40, left: 10, containLabel: true },
        xAxis: {
          type: 'category',
          data: labels,
          axisLabel: { color: '#8ba6c8', fontSize: 10, interval: 0, rotate: 12 },
          axisLine: { lineStyle: { color: 'rgba(0,212,255,0.2)' } }
        },
        yAxis: {
          type: 'value',
          axisLabel: { color: '#8ba6c8', fontSize: 11 },
          splitLine: { lineStyle: { color: 'rgba(0,212,255,0.1)' } },
          axisLine: { show: false }
        },
        series: [{
          type: 'bar',
          data: counts.map((v, i) => ({
            value: v,
            itemStyle: { color: colors[i], borderRadius: [3, 3, 0, 0] }
          })),
          barMaxWidth: 32,
          label: { show: true, position: 'top', color: '#a8c5e6', fontSize: 11 }
        }]
      })
      this.hrChart.off('click')
      this.hrChart.on('click', (params) => {
        const rangeMap = {
          '过缓<50':      { min: 0,   max: 49  },
          '偏缓50~60':    { min: 50,  max: 60  },
          '正常61~100':   { min: 61,  max: 100 },
          '偏速101~120':  { min: 101, max: 120 },
          '过速>120':     { min: 121, max: 999 }
        }
        const range = rangeMap[params.name]
        if (range) {
          this.hrFilter = this.hrFilter && this.hrFilter.label === params.name
            ? null
            : { ...range, label: params.name }
          this.currentPage = 1
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
/* ===== Root ===== */
.rt-root {
  width: 1920px;
  height: 1030px;
  background: #0a0e27;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  font-family: 'Microsoft YaHei', sans-serif;
  color: #a8c5e6;
}

/* ===== Header ===== */
.rt-hd {
  height: 60px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  padding: 0 24px;
  background: rgba(0, 8, 28, 0.6);
  border-bottom: 1px solid rgba(0, 212, 255, 0.2);
  gap: 24px;
}

.rt-hd-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}

.rt-live-dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: #00d4ff;
  box-shadow: 0 0 8px #00d4ff;
  animation: blink 1.5s infinite;
}

.rt-hd-title {
  font-size: 20px;
  font-weight: bold;
  color: #fff;
  margin: 0;
  white-space: nowrap;
  text-shadow: 0 0 15px rgba(0, 212, 255, 0.5);
}

.rt-hd-kpis {
  display: flex;
  flex: 1;
  justify-content: center;
}

.rt-kpi {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 30px;
  border-right: 1px solid rgba(0, 212, 255, 0.2);
  transition: background 0.2s;
  &:first-child { border-left: 1px solid rgba(0, 212, 255, 0.2); }
  &[style*="pointer"]:hover {
    background: rgba(0, 212, 255, 0.06);
  }
}

.rt-kpi-n {
  font-size: 22px;
  font-weight: bold;
  font-family: 'Consolas', monospace;
  color: #00d4ff;
  line-height: 1.1;
  margin-bottom: 2px;
  &.kpi-green  { color: #67C23A; }
  &.kpi-yellow { color: #f0d060; }
  &.kpi-warn   { color: #E6A23C; }
}

.rt-kpi-l {
  font-size: 11px;
  color: #8ba6c8;
  white-space: nowrap;
}

.rt-hd-time {
  flex-shrink: 0;
  font-family: 'Consolas', monospace;
  font-size: 14px;
  color: #8ba6c8;
  white-space: nowrap;
}

/* ===== Body ===== */
.rt-bd {
  flex: 1;
  display: flex;
  gap: 10px;
  padding: 10px;
  overflow: hidden;
}

/* ===== Left aside (6 vital cards) ===== */
.rt-aside {
  width: 195px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.rt-vital {
  flex: 1;
  background: rgba(10, 18, 48, 0.65);
  border: 1px solid rgba(0, 212, 255, 0.2);
  border-radius: 8px;
  padding: 12px 14px;
  display: flex;
  align-items: center;
  gap: 11px;
  position: relative;
  transition: border-color 0.25s, background 0.25s;

  &:hover {
    border-color: rgba(0, 212, 255, 0.4);
    background: rgba(0, 28, 70, 0.75);
  }
}

.rt-vital-ico {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.rt-vital-info { flex: 1; min-width: 0; }

.rt-vital-val {
  font-size: 21px;
  font-weight: bold;
  font-family: 'Consolas', monospace;
  line-height: 1.2;
}

.rt-vital-lbl {
  font-size: 12px;
  color: #a8c5e6;
  margin-top: 2px;
}

.rt-vital-sub {
  font-size: 11px;
  color: #6b7b94;
  margin-top: 1px;
}

.rt-vital-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  position: absolute;
  top: 10px;
  right: 10px;
  flex-shrink: 0;

  &.dot-ok     { background: #67C23A; box-shadow: 0 0 6px #67C23A; }
  &.dot-warn   { background: #E6A23C; box-shadow: 0 0 6px #E6A23C; animation: blink 1.5s infinite; }
  &.dot-danger { background: #F56C6C; box-shadow: 0 0 6px #F56C6C; animation: blink 1s infinite; }
  &.dot-none   { background: #4a5568; }
}

/* ===== Center (table) ===== */
.rt-main {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.rt-panel {
  background: rgba(10, 18, 48, 0.65);
  border: 1px solid rgba(0, 212, 255, 0.2);
  border-radius: 10px;
  overflow: hidden;
}

.rt-table-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.rt-ph {
  padding: 10px 16px;
  border-bottom: 1px solid rgba(0, 212, 255, 0.15);
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
  gap: 10px;
}

.rt-ph-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

.rt-ph-dot {
  width: 6px;
  height: 6px;
  background: #00d4ff;
  border-radius: 50%;
  box-shadow: 0 0 6px #00d4ff;
}

.rt-ph-title {
  font-size: 15px;
  font-weight: bold;
  color: #e0f0ff;
  white-space: nowrap;
}

.rt-badge-online {
  font-size: 12px;
  color: #22c55e;
  background: rgba(34, 197, 94, 0.15);
  border: 1px solid rgba(34, 197, 94, 0.35);
  border-radius: 10px;
  padding: 1px 10px;
}

.rt-badge-filter {
  font-size: 12px;
  color: #00d4ff;
  background: rgba(0, 212, 255, 0.12);
  border: 1px solid rgba(0, 212, 255, 0.4);
  border-radius: 10px;
  padding: 1px 10px;
  cursor: pointer;
  transition: background 0.2s;
  &:hover {
    background: rgba(0, 212, 255, 0.22);
  }
}

.rt-ph-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Input / Select dark theme */
.rt-inp {
  width: 150px;
  :deep(.el-input__wrapper) {
    background: rgba(0, 25, 60, 0.7) !important;
    border: 1px solid rgba(0, 212, 255, 0.3) !important;
    box-shadow: none !important;
  }
  :deep(.el-input__inner) {
    color: #a8c5e6;
    &::placeholder { color: #5a6a80; }
  }
}

.rt-sel {
  width: 130px;
  :deep(.el-select__wrapper) {
    background: rgba(0, 25, 60, 0.7) !important;
    border: 1px solid rgba(0, 212, 255, 0.3) !important;
    box-shadow: none !important;
  }
  :deep(.el-select__placeholder)          { color: #5a6a80 !important; }
  :deep(.el-select__selected-item span)   { color: #a8c5e6 !important; }
  :deep(.el-select__caret)                { color: #00d4ff !important; }
}

.rt-sel-sm {
  width: 110px;
  :deep(.el-select__wrapper) {
    background: rgba(0, 25, 60, 0.7) !important;
    border: 1px solid rgba(0, 212, 255, 0.3) !important;
    box-shadow: none !important;
  }
  :deep(.el-select__placeholder)          { color: #5a6a80 !important; }
  :deep(.el-select__selected-item span)   { color: #a8c5e6 !important; }
  :deep(.el-select__caret)                { color: #00d4ff !important; }
}

.rt-btn {
  padding: 7px 14px;
  background: linear-gradient(135deg, rgba(0, 212, 255, 0.18), rgba(0, 80, 200, 0.18));
  border: 1px solid rgba(0, 212, 255, 0.4);
  border-radius: 5px;
  color: #00d4ff;
  font-size: 13px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
  transition: all 0.25s;

  &:hover {
    background: linear-gradient(135deg, rgba(0, 212, 255, 0.28), rgba(0, 80, 200, 0.28));
    box-shadow: 0 0 8px rgba(0, 212, 255, 0.3);
  }
  &:active { transform: scale(0.96); }
}

.rt-btn-g {
  padding: 7px 10px;
  background: rgba(255, 255, 255, 0.06);
  border-color: rgba(255, 255, 255, 0.15);
  color: #8ba6c8;
  &:hover { background: rgba(255, 255, 255, 0.1); box-shadow: none; }
}

/* Table wrapper */
.rt-tbl-wrap {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;

  &::-webkit-scrollbar       { width: 4px; }
  &::-webkit-scrollbar-track { background: rgba(0, 20, 50, 0.4); }
  &::-webkit-scrollbar-thumb { background: rgba(0, 212, 255, 0.3); border-radius: 2px; }

  :deep(.el-table) {
    --el-table-border-color: rgba(0, 212, 255, 0.2) !important;
    --el-table-row-hover-bg-color: rgba(0, 80, 180, 0.3) !important;
    --el-table-bg-color: transparent !important;
    --el-table-tr-bg-color: transparent !important;
    background: transparent !important;

    &::before { display: none; }

    .el-table__header th.el-table__cell {
      background: rgba(0, 40, 90, 0.9) !important;
      border-color: rgba(0, 212, 255, 0.3) !important;
      color: #00d4ff !important;
    }

    .el-table__body tr {
      background: transparent;
      &:nth-child(even) td { background: rgba(0, 30, 70, 0.25) !important; }
      &:hover > td        { background: rgba(0, 80, 180, 0.3) !important; }
    }

    td.el-table__cell { border-color: rgba(0, 212, 255, 0.15) !important; }
  }
}

/* Cell value color classes */
.c-name   { color: #00d4ff; font-weight: 500; }
.c-code   { color: #8ba6c8; }
.c-dept   { color: #a8c5e6; }
.c-steps  { color: #22c55e; font-weight: 500; }
.c-sleep  { color: #a855f7; font-weight: 500; }
.c-time   { color: #8ba6c8; font-size: 12px; }
.c-dim    { color: #6b7b94; }
.c-ok     { color: #67C23A; font-weight: 600; }
.c-warn   { color: #E6A23C; font-weight: 600; }
.c-danger { color: #F56C6C; font-weight: 600; }

.rt-status {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 10px;
  font-size: 12px;
  font-weight: 500;
  &.st-ok {
    background: rgba(103, 194, 58, 0.18);
    color: #67C23A;
    border: 1px solid rgba(103, 194, 58, 0.4);
  }
  &.st-warn {
    background: rgba(230, 162, 60, 0.18);
    color: #E6A23C;
    border: 1px solid rgba(230, 162, 60, 0.4);
    animation: blink 2s infinite;
  }
}

/* Pagination */
.rt-pg {
  padding: 8px 16px;
  border-top: 1px solid rgba(0, 212, 255, 0.15);
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

.rt-pg-btn {
  min-width: 50px;
  height: 30px;
  padding: 0 10px;
  background: rgba(20, 60, 120, 0.3);
  border: 1px solid rgba(0, 212, 255, 0.3);
  border-radius: 4px;
  color: #00d4ff;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.25s;

  &:hover:not(:disabled) {
    background: rgba(0, 212, 255, 0.2);
    border-color: #00d4ff;
  }
  &:disabled { opacity: 0.3; cursor: not-allowed; }
}

.rt-pg-info {
  color: #00d4ff;
  font-size: 14px;
  font-weight: 500;
  min-width: 70px;
  text-align: center;
}

.rt-pg-total {
  color: #8ba6c8;
  font-size: 12px;
  margin-left: 6px;
}

/* ===== Right charts column ===== */
.rt-charts {
  width: 300px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.rt-cp {
  display: flex;
  flex-direction: column;
  padding: 10px 12px;
  flex: 1;
}

.rt-cp-md { flex: 1.6; }

.rt-cp-title {
  font-size: 13px;
  font-weight: bold;
  color: #a8c5e6;
  margin-bottom: 6px;
  flex-shrink: 0;
  padding-left: 8px;
  border-left: 3px solid #00d4ff;
}

.rt-ec {
  flex: 1;
  min-height: 0;
}

/* ===== Dialog dark theme override ===== */
:deep(.el-dialog) {
  background: #0d1535 !important;
  border: 1px solid rgba(0, 212, 255, 0.25) !important;
  border-radius: 10px !important;
  box-shadow: 0 0 40px rgba(0, 80, 200, 0.4) !important;

  .el-dialog__header {
    background: rgba(0, 25, 70, 0.8) !important;
    border-bottom: 1px solid rgba(0, 212, 255, 0.2) !important;
    padding: 14px 20px !important;
    margin-right: 0 !important;
    border-radius: 10px 10px 0 0 !important;
  }

  .el-dialog__title {
    color: #00d4ff !important;
    font-size: 15px !important;
    font-weight: bold !important;
  }

  .el-dialog__headerbtn {
    top: 14px !important;
    right: 16px !important;

    .el-dialog__close {
      color: #8ba6c8 !important;
      font-size: 18px !important;
      &:hover { color: #00d4ff !important; }
    }
  }

  .el-dialog__body {
    background: transparent !important;
    padding: 16px 20px 20px !important;
    color: #a8c5e6 !important;
  }
}

/* ===== Animations ===== */
@keyframes blink {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.3; }
}
</style>
